#!/usr/bin/env python


import rospy
from nav_msgs.msg import Odometry  # from : packagename.namespace or topic import : message class
from sensor_msgs.msg import Imu
from sensor_msgs.msg import JointState



def imu_callback(msg):
    quat_x = msg.orientation.x
    quat_y = msg.orientation.y
    quat_z = msg.orientation.z
    accel_x = msg.linear_acceleration.x
    accel_y = msg.linear_acceleration.y
    accel_z = msg.linear_acceleration.z

#    rospy.loginfo("Quaternion orientation");
#    rospy.loginfo("x: %f, y: %f, z:%f",quat_x,quat_y,quat_z);
#    rospy.loginfo("Linear acceleration");
#    rospy.loginfo("x: %f, y: %f, z:%f",accel_x,accel_y,accel_z);
#    rospy.loginfo("Quaternion orientation");
#    rospy.loginfo("x: %f, y: %f, z:%f",quat_x,quat_y,quat_z);
#    rospy.loginfo("Linear acceleration");
#    rospy.loginfo("x: %f, y: %f, z:%f",accel_x,accel_y,accel_z);




def joint_callback(msg):

    name = msg.name
    position = msg.position
    velocity = msg.velocity
    effort = msg.effort
    print "joint name:", name[0],name[1],name[2],name[3]
    rospy.loginfo("Position: %.5f, %.5f, %.5f, %.5f",position[0],position[1],position[2],position[3])
#    rospy.loginfo("velocity: %.5f, %.5f, %.5f, %.5f",velocity[0],velocity[1],velocity[2],velocity[3])
#    rospy.loginfo("effort: %5.2f, %5.2f, %5.2f, %5.2f",effort[0],effort[1],effort[2],effort[3])
    print "Position:",position[0],position[1],position[2],position[3]
    print "velocity:",velocity[0],velocity[1],velocity[2],velocity[3]
    print "effort:",effort[0],effort[1],effort[2],effort[3]


def start():

    rospy.init_node('get_sensor_data', anonymous=True) #it will be the nodename
    imu_sub = rospy.Subscriber("/mecanum_wheel_model/imu",Imu,imu_callback)
    joint_sub = rospy.Subscriber("/mobile_robot/joint_states",JointState,joint_callback)

#    rate = rospy.Rate(10) # 10Hz

    rospy.loginfo("im working")

    rospy.spin() #runforever before system crashed etc..



if __name__ == '__main__':
#    rospy.init_node('get_sensor_data', anonymous=True) #it will be the nodename
    start()

