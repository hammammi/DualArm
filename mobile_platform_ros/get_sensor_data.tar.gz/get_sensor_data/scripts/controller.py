#!/usr/bin/env python

import rospy

from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

global cmd_vel

cmd_vel = Twist()
pub = rospy.Publisher('/mobile_robot/cmd_vel', Twist,queue_size=10)

cmd_vel.linear.x = .0
cmd_vel.linear.y = .0
cmd_vel.linear.z = .0
cmd_vel.angular.x = .0
cmd_vel.angular.y = .0
cmd_vel.angular.z = .0

# = 'linear:  {x: 1, y: 0.0, z: 0.0}, angular: {x: 0.0,y: 0.0,z: 0.0}'
#cmd_vel = [[1, 0.0, 0.0], [0.0, 0.0, 0.0]]




def OdomCallback(msg):
        pos_x = msg.pose.pose.position.x
        pos_y = msg.pose.pose.position.y

        ori_ = msg.pose.pose.orientation.z

        lin_x = msg.twist.twist.linear.x
        lin_y = msg.twist.twist.linear.y

        ang_ = msg.twist.twist.angular.z

	cmd_vel.linear.x = 1
	cmd_vel.linear.y = -lin_y
	cmd_vel.linear.z = .0
	cmd_vel.angular.x = .0
	cmd_vel.angular.y = .0
	cmd_vel.angular.z = -ang_

        pub.publish(cmd_vel)
        rospy.loginfo(cmd_vel)



def start():

        rospy.init_node('contoller',anonymous=True)
        rate = rospy.Rate(10)  #10Hz

        imu_sub = rospy.Subscriber("/mobile_robot/odom",Odometry,OdomCallback)

        pub.publish(cmd_vel)
        rospy.loginfo(cmd_vel)

        rospy.spin()






if __name__ == '__main__':
        start()
