#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/JointState.h"


sensor_msgs::JointState js;

void imu_Callback(const sensor_msgs::Imu::ConstPtr& msg){
    double quat_x = msg->orientation.x;
    double quat_y = msg->orientation.y;
    double quat_z = msg->orientation.z;

    double accel_x = msg->linear_acceleration.x;
    double accel_y = msg->linear_acceleration.y;
    double accel_z = msg->linear_acceleration.z;

    ROS_INFO("Quaternion orientation");
    ROS_INFO("x: %f, y: %f, z:%f",quat_x,quat_y,quat_z);
    ROS_INFO("Linear acceleration");
    ROS_INFO("x: %f, y: %f, z:%f",accel_x,accel_y,accel_z);


}

void jointState_Callback(const sensor_msgs::JointState::ConstPtr& msg){
    std::string name[4];
    double position[4]; 
    double velocity[4]; 
    double effort[4];
     
    for (unsigned int i = 0; i < js.name.size(); i++){
        name[i] = js.name[i];
        position[i] = msg->position[i];
        velocity[i] = js.velocity[i];
        effort[i] = js.effort[i];
    }
    ROS_INFO("joint name: %s, %s, %s, %s",name[0].c_str(),name[1].c_str(),name[2].c_str(),name[3].c_str());
    ROS_INFO("Position: %f, %f, %f, %f",position[0],position[1],position[2],position[3]);
    ROS_INFO("velocity: %f, %f, %f, %f",velocity[0],velocity[1],velocity[2],velocity[3]);
    ROS_INFO("effort: %f, %f, %f, %f",effort[0],effort[1],effort[2],effort[3]);
}

int main(int argc, char** argv){
    ros::init(argc,argv,"get_sensor_data");
    ros::NodeHandle nh;
    ros::Subscriber imu_sub = nh.subscribe("/mecanum_wheel_model/imu",10,imu_Callback);
    ros::Subscriber joint_sub = nh.subscribe("/mobile_robot/joint_states",1,jointState_Callback);
    ros::spin();
    return 0;


}
