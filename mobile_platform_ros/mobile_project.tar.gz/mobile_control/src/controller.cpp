#include <math.h>
#include "ros/ros.h"
#include "mobile_control/cmdMsg.h"
#include "mobile_control/motorMsg.h"
#include "nav_msgs/Odometry.h"
#include <geometry_msgs/Twist.h>


#define PI 3.14159265358979323846

/* Declare Global Variable */
// From cmd_msg //
double pos_des[3];

// From odometry msg //
double pos_act[2];
double vel_act[3];
double quat_act[4];

void cmdCallback(const mobile_control::cmdMsg::ConstPtr& cmd_msg)
{
    pos_des[0]   = cmd_msg->xd;
    pos_des[1]   = cmd_msg->yd;
    pos_des[2]   = cmd_msg->phid;
}

void odomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
    pos_act[0] = msg->pose.pose.position.x;
    pos_act[1] = msg->pose.pose.position.y;

    vel_act[0]  = msg->twist.twist.linear.x;
    vel_act[1]  = msg->twist.twist.linear.y;
    vel_act[2]  = msg->twist.twist.angular.z;

    quat_act[0] = msg->pose.pose.orientation.x;
    quat_act[1] = msg->pose.pose.orientation.y;
    quat_act[2] = msg->pose.pose.orientation.z;
    quat_act[3] = msg->pose.pose.orientation.w;
}
int main(int argc, char **argv)
{
  ros::init(argc,argv,"mob_control");
  ros::NodeHandle nh;
  //100 que size//
  ros::Publisher ctrl_pub=nh.advertise<geometry_msgs::Twist>("/cmd_vel",100);
  ros::Publisher publ_input = nh.advertise<mobile_control::motorMsg>("/input_msg",100);

  // Quesize : 100 //
  ros::Subscriber sub1 = nh.subscribe("/ns1/cmd_msg",100,cmdCallback);
  ros::Subscriber sub2 = nh.subscribe("/odom",100,odomCallback);
  // Publish rate : 50Hz //
  ros::Rate loop_rate(50);

  // time unit : sec & loop time = 1/50 sec (50Hz) //
  double dt = 0.02;


//** Initialization **//
  // reference {prev, current} //
  double x_d[2]      = {0, 0};
  double y_d[2]      = {0, 0};
  double phi_d[2]    = {0, 0};
  
  // From Odometry //
  double x_act[2]    = {0, 0};
  double y_act[2]    = {0, 0};
  double phi_act[2]  = {0, 0};

  double vx_act[2]   = {0, 0};
  double vy_act[2]   = {0, 0};
  double dphi_act[2] = {0, 0};

  double x_quat   = 0;
  double y_quat   = 0;
  double z_quat   = 0;
  double w_quat   = 0;

//** Controller gains Setting **//

  // P control //
  double kx1 = 10.0;
  double ky1 = 10.0;
  double kp1 = 1.0;

  // D control //
  double kx2 = 0.01;
  double ky2 = 0.01;
  double kp2 = 0.01;

  // I control //
  double kx3 = 0.004;
  double ky3 = 0.004;
  double kp3 = 0.001;

  // accumulated error //
  double Ix = 0.0;
  double Iy = 0.0;
  double Ip = 0.0;

// Input(Velocity) //

  double u_x = 0;
  double u_y = 0;
  double u_p = 0;

// Linear velocity : 0.2m/s, dphidt constraint :  deg/sec ( 0.1 rad/sec ), and scale factor  //
  double v_lim       = 2;
  double dphidt_lim  = 0.1;
  double scale=0;

// Wheel specification in meter //
  double wheel_diameter = 0.152;
  double wheel_separation_a = 0.2355;
  double wheel_separation_b = 0.281;
  double l = wheel_separation_a + wheel_separation_b;


// Motor speed in rad/sec - initialization //
  double wheel_speed_lf = 0;
  double wheel_speed_rf = 0;
  double wheel_speed_lb = 0;
  double wheel_speed_rb = 0;

// Gear ratio //

  int gear_ratio = 76;

// rad/sec --> rpm //

  double conv_ratio = 60.0/2.0/PI;

// Motor speed in RPM - initialization //
  int w1 = 0;
  int w2 = 0;
  int w3 = 0;
  int w4 = 0;


  while(ros::ok())
  {
    
    geometry_msgs::Twist cmd_vel;
    mobile_control::motorMsg input_msg;
    
    // Current values from reference  phi --> rad//
    x_d[1]      = pos_des[0];
    y_d[1]      = pos_des[1];
    phi_d[1]    = pos_des[2];

    // Current values from Odometry  //
    
    x_act[1]    = pos_act[0];
    y_act[1]    = pos_act[1];

    vx_act[1]   = vel_act[0];
    vy_act[1]   = vel_act[1];
    dphi_act[1] = vel_act[2];

    x_quat   = quat_act[0];
    y_quat   = quat_act[1];
    z_quat   = quat_act[2];
    w_quat   = quat_act[3];
    
     

    phi_act[1]  = atan2(2.0 * (w_quat * z_quat + x_quat * y_quat),
                        1.0-2.0 * (y_quat*y_quat + z_quat * z_quat));

    u_x =  kx1 * (x_d[1] - x_act[1])
         +kx2 * ((x_d[1] - x_d[0])-(x_act[1] - x_act[0]))/dt
            +kx3 * Ix * dt;

    u_y =  ky1 * (y_d[1]-y_act[1])
         +ky2 * ((y_d[1] - y_d[0])-(y_act[1] - y_act[0]))/dt
            +ky3 * Iy * dt;
         
    u_p =  kp1 * (phi_d[1]-phi_act[1])
         +kp2 * ((phi_d[1] - phi_d[0])-(phi_act[1] - phi_act[0]))/dt
            +kp3 * Ip * dt;




    if(sqrt(u_x*u_x+u_y*u_y)>v_lim)
    { 
      scale = v_lim/sqrt(u_x*u_x+u_y*u_y);
      u_x = scale * u_x;
      u_y = scale * u_y;

    }

    if(dphidt_lim < u_p)
    {
      u_p = dphidt_lim;
    }
    else if(-dphidt_lim > u_p)
    {
      u_p = -dphidt_lim;

    }

    u_x = u_x * cosf(phi_act[1]) + u_y * sinf(phi_act[1]);
    u_y =-u_x * sinf(phi_act[1]) + u_y * cosf(phi_act[1]);


ROS_INFO("x : %lf y : %lf phi : %lf",x_act[1],y_act[1],phi_act[1]);
    


    wheel_speed_lf = 2.0 / wheel_diameter * ( u_x + u_y - l * u_p);
    wheel_speed_rf = 2.0 / wheel_diameter * (-u_x + u_y + l * u_p);
    wheel_speed_lb = 2.0 / wheel_diameter * (-u_x + u_y - l * u_p);
    wheel_speed_rb = 2.0 / wheel_diameter * ( u_x + u_y + l * u_p);

    w1 = (int) wheel_speed_lf * conv_ratio * gear_ratio;
    w2 = (int) wheel_speed_rf * conv_ratio * gear_ratio;
    w3 = (int) wheel_speed_lb * conv_ratio * gear_ratio;
    w4 = (int) wheel_speed_rb * conv_ratio * gear_ratio;

    if(u_x * u_x + u_y * u_y + u_p * u_p < 0.01*0.01){
        w1 = 0;
        w2 = 0;
        w3 = 0;
        w4 = 0;

        u_x = 0;
        u_y = 0;
        u_p = 0;
    }


    cmd_vel.linear.x  = u_x;
    cmd_vel.linear.y  = u_y;
    cmd_vel.angular.z = u_p;

    input_msg.omega1 = w1;
    input_msg.omega2 = w2;
    input_msg.omega3 = w3;
    input_msg.omega4 = w4;



    ctrl_pub.publish(cmd_vel);
    publ_input.publish(input_msg);
    ros::spinOnce();
    loop_rate.sleep();

        // Last values from reference  phi --> rad//
    x_d[0]      = x_d[1];
    y_d[0]      = y_d[1];
    phi_d[0]    = phi_d[1];

    // Last values from Odometry  //
    
    x_act[0]    = x_act[1];
    y_act[0]    = y_act[1];
    phi_act[0]  = phi_act[1];
  
    vx_act[0]   = vx_act[1];
    vy_act[0]   = vy_act[1];
    dphi_act[0] = dphi_act[1];

    // Accumulated error update //
    Ix = Ix + (x_d[1] - x_act[1])*dt;
    Iy = Iy + (y_d[1] - y_act[1])*dt;
    Ip = Ip + (phi_d[1] - phi_act[1])*dt;

  }

  return 0;

}

