#include <math.h>
#include "ros/ros.h"
#include "mobile_control/cmdMsg.h"
#include "mobile_control/inputDataMsg.h"
#include "nav_msgs/Odometry.h"

double pos_des[3];

double pos_act[2];
double vel_act[3];
double quat_act[4];



void msgCallback(const mobile_control::cmdMsg::ConstPtr& cmd_msg)
{

  mobile_control::inputDataMsg input_data;

  pos_des[0]   = cmd_msg->xd;
  pos_des[1]   = cmd_msg->yd;
  pos_des[2]   = cmd_msg->phid;

}

void odomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{

    mobile_control::inputDataMsg input_data;
  pos_act[0] = msg->pose.pose.position.x;
  pos_act[1] = msg->pose.pose.position.y;

  vel_act[0]  = msg->twist.twist.linear.x;
  vel_act[1]  = msg->twist.twist.linear.y;
  vel_act[2] = msg->twist.twist.angular.z;

  quat_act[0] = msg->pose.pose.orientation.x;
  quat_act[1] = msg->pose.pose.orientation.y;
  quat_act[2] = msg->pose.pose.orientation.z;
  quat_act[3] = msg->pose.pose.orientation.w;

}


int main(int argc,char **argv)
{

  ros::init(argc,argv,"cmd_msg_subscriber");
  ros::NodeHandle nh;
  ros::Publisher pub = nh.advertise<mobile_control::inputDataMsg>("/input_data",100);
  ros::Subscriber cmd_sub  = nh.subscribe("/ns1/cmd_msg",100,msgCallback);
  ros::Subscriber odom_sub = nh.subscribe("/odom",100,odomCallback);

  mobile_control::inputDataMsg input_data;
  while(ros::ok()){

          input_data.xd   = pos_des[0];
          input_data.yd   = pos_des[1];
          input_data.phid = pos_des[2];

          input_data.xact = pos_act[0];
          input_data.yact = pos_act[1];

          input_data.vxact   = vel_act[0];
          input_data.vyact   = vel_act[1];
          input_data.dphiact = vel_act[2];

          input_data.xquat = quat_act[0];
          input_data.yquat = quat_act[1];
          input_data.zquat = quat_act[2];
          input_data.wquat = quat_act[3];

  ROS_INFO("Desired Input : %lf %lf %lf",input_data.xd,input_data.yd,input_data.phid);
  pub.publish(input_data);
  ros::spinOnce();
  }


  return 0;


}
