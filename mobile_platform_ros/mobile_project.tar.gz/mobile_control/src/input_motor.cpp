
#include "ros/ros.h"
#include "mobile_control/motorMsg.h"

void callbackMotorInput(const mobile_control::motorMsg::ConstPtr& input_msg)
{
    int w1 = input_msg->omega1;
    int w2 = input_msg->omega2;
    int w3 = input_msg->omega3;
    int w4 = input_msg->omega4;
    ROS_INFO("left front: %d right front: %d left back: %d right back: %d",w1,w2,w3,w4);
}

int main(int argc,char **argv)
{
    ros::init(argc,argv,"Input_motor");
    ros::NodeHandle nh;

    ros::Subscriber sub_motorInput = nh.subscribe("/input_msg",100,callbackMotorInput);
    ros::spin();

    return 0;
}
