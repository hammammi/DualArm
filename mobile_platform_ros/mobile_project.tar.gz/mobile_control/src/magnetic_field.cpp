#include <sensor_msgs/MagneticField>

