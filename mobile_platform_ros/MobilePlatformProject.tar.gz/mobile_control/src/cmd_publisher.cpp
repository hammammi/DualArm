#include "ros/ros.h"
#include "mobile_control/cmdMsg.h"

int main(int argc, char **argv)
{
  ros::init(argc,argv,"cmd_msg_publisher");
  ros::NodeHandle nh;

  ros::Publisher cmd_pub=nh.advertise<mobile_control::cmdMsg>("/ns1/cmd_msg",100); //100 que size//
  ros::Rate loop_rate(10); //10 Hz //


  //** Initialization of command variables **//

  float x_d[5]   = {10, 10, 10, 10, 10};
  float y_d[5]   = {5, 5, 5, 5, 5};
  float phi_d[5] = {0.4, 0.4, 0.4, 0.4, 0.4};



  while(ros::ok())
  {

    mobile_control::cmdMsg cmd_msg;
    
    


    for(int i=0;i<5;i++){

    cmd_msg.xd   = x_d[i];
    cmd_msg.yd   = y_d[i];  
    cmd_msg.phid = phi_d[i];

    cmd_pub.publish(cmd_msg);

    ROS_INFO("Pub Msg : %lf %lf %lf",x_d[i],y_d[i],phi_d[i]);
     if(i==4){
                  loop_rate.sleep();
              }

    }
  }

  return 0;

}

