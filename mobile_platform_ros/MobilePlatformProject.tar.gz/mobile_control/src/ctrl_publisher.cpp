#include "ros/ros.h"
#include "mobile_control/inputDataMsg.h"
#include <geometry_msgs/Twist.h>

double pos_des[3];

double pos_act[2];
double vel_act[3];
double quat_act[4];

void callback(const mobile_control::inputDataMsg::ConstPtr& input_data)
{
    pos_des[0]   = input_data->xd;
    pos_des[1]   = input_data->yd;
    pos_des[2]   = input_data->phid;

    pos_act[0] = input_data->xact;
    pos_act[1] = input_data->yact;

    vel_act[0]  = input_data->vxact;
    vel_act[1]  = input_data->vyact;
    vel_act[2]  = input_data->dphiact;

    quat_act[0] = input_data->xquat;
    quat_act[1] = input_data->yquat;
    quat_act[2] = input_data->zquat;
    quat_act[3] = input_data->wquat;
}


int main(int argc, char **argv)
{
  ros::init(argc,argv,"mob_controller");
  ros::NodeHandle nh;
  //100 que size//
  ros::Publisher ctrl_pub=nh.advertise<geometry_msgs::Twist>("/cmd_vel",10); 
  //10 Hz //
  ros::Subscriber sub = nh.subscribe("/input_data",10,callback);
  ros::Rate loop_rate(10); 


//** Initialization **//
  // reference [prev, current] //
  double x_d[2]      = {0, 0};
  double y_d[2]      = {0, 0};
  double phi_d[2]    = {0, 0};
  
  // From Odometry //
  double x_act[2]    = {0, 0};
  double y_act[2]    = {0, 0};
  double phi_act[2]  = {0, 0};

  double vx_act[2]   = {0, 0};
  double vy_act[2]   = {0, 0};
  double dphi_act[2] = {0, 0};

  double x_quat   = 0;
  double y_quat   = 0;
  double z_quat   = 0;
  double w_quat   = 0;

//** Controller gains Setting **//
  double kx1 = 10.0;
  double ky1 = 10.0;
  double kp1 = 1.0;

  double kx2 = 1.0;
  double ky2 = 1.0;
  double kp2 = 1.0;

// Input(Velocity) //

  double u_x = 0;
  double u_y = 0;
  double u_p = 0;

// Linear velocity, dphidt constraint, and scale factor  //
  double v_lim       = 5;
  double dphidt_lim  = 3;
  double scale=0;

  // time unit : sec & loop time = 0.1 sec//
  double dt = 0.1;
  ROS_INFO("xx");
  while(ros::ok())
  {
    
    mobile_control::inputDataMsg input_data;
    geometry_msgs::Twist cmd_vel;
    
    // Current values from reference  phi --> rad//
    x_d[1]      = pos_des[0];
    y_d[1]      = pos_des[1];
    phi_d[1]    = pos_des[2];

    // Current values from Odometry  //
    
    x_act[1]    = pos_act[0];
    y_act[1]    = pos_act[1];

    vx_act[1]   = vel_act[0];
    vy_act[1]   = vel_act[1];
    dphi_act[1] = vel_act[2];

    x_quat   = quat_act[0];
    y_quat   = quat_act[1];
    z_quat   = quat_act[2];
    w_quat   = quat_act[3];
    
     
    
    phi_act[1]  = atan2(2.0 * (w_quat * z_quat + x_quat * y_quat),
                        1.0-2.0 * (y_quat*y_quat + z_quat * z_quat));

    u_x =  kx1 * (x_d[1] - x_act[1])
         +kx2 * ((x_d[1] - x_d[0])-(x_act[1] - x_act[0]))/dt;

    u_y =  ky1 * (y_d[1]-y_act[1])
         +ky2 * ((y_d[1] - y_d[0])-(y_act[1] - y_act[0]))/dt;
         
    u_p =  kp1 * (phi_d[1]-phi_act[1])
         +kp2 * ((phi_d[1] - phi_d[0])-(phi_act[1] - phi_act[0]))/dt;

    if(sqrt(u_x*u_x+u_y*u_y)>v_lim)
    { 
      scale = v_lim/sqrt(u_x*u_x+u_y*u_y);
      u_x = scale * u_x;
      u_y = scale * u_y;

    }

    if(dphidt_lim < u_p)
    {
      u_p = dphidt_lim;
    }
    else if(-dphidt_lim > u_p)
    {
      u_p = -dphidt_lim;
    }

    
    cmd_vel.linear.x  = u_x;
    cmd_vel.linear.y  = u_y;
    cmd_vel.angular.z = u_p;

    ROS_INFO("%lf %lf %lf ",input_data.yd,u_y,scale);
    
    ctrl_pub.publish(cmd_vel);
    ros::spinOnce();

        // Last values from reference  phi --> rad//
    x_d[0]      = x_d[1];
    y_d[0]      = y_d[1];
    phi_d[0]    = phi_d[1];

    // Last values from Odometry  //
    
    x_act[0]    = x_act[1];
    y_act[0]    = y_act[1];
    phi_act[0]  = phi_act[1];
  
    vx_act[0]   = vx_act[1];
    vy_act[0]   = vy_act[1];
    dphi_act[0] = dphi_act[1];


  }

  return 0;

}

