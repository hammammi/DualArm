
#include "ros/ros.h"
#include "mobile_control/cmdMsg.h"
#include "mobile_control/inputDataMsg.h"
#include "nav_msgs/Odometry.h"



void msgCallback(const mobile_control::cmdMsg::ConstPtr& cmd_msg)
{
  mobile_control::inputDataMsg input_data;
  input_data.xd   = cmd_msg->xd;
  input_data.yd   = cmd_msg->yd;
  input_data.phid = cmd_msg->phid;
}

void odomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
  mobile_control::inputDataMsg input_data;
  input_data.xact = msg->pose.pose.position.x;
  input_data.yact = msg->pose.pose.position.y;

  input_data.vxact  = msg->twist.twist.linear.x;
  input_data.vyact  = msg->twist.twist.linear.y;
  input_data.dphiact = msg->twist.twist.angular.z;

  input_data.xquat = msg->pose.pose.orientation.x;
  input_data.yquat = msg->pose.pose.orientation.y;
  input_data.zquat = msg->pose.pose.orientation.z;
  input_data.wquat = msg->pose.pose.orientation.w;
}


int main(int argc,char **argv)
{

  ros::init(argc,argv,"cmd_msg_subscriber");
  ros::NodeHandle nh;

  //** publish given input data to be processed **//
  ros::Publisher  pub      = nh.advertise<mobile_control::inputDataMsg>("input_data",10);
  ros::Subscriber cmd_sub  = nh.subscribe("/ns1/cmd_msg",10,msgCallback);
  ros::Subscriber odom_sub = nh.subscribe("/odom",10,odomCallback);

 

  ros::spin();

  return 0;

}
